//
//  VehicleListViewModel.m
//  FreeNowVehicles
//
//  Created by Ashish Patel on 2021/11/20.
//

#import "VehicleListViewModel.h"
#import "FreeNowVehicles-Swift.h"

@interface VehicleListViewModel ()
@property (nonatomic, readwrite) id <VehiclesBoundary> vehiclesBoundary;
@property (nonatomic, weak) id<VehicleListDelegate> delegate;
@property (nonatomic, strong) NSMutableArray<Vehicle *> *vehicles;
@end

@implementation VehicleListViewModel

- (instancetype)initWithDelegate:(id <VehicleListDelegate>)delegate withVehiclesBoundary:(id <VehiclesBoundary>)vehiclesBoundary {
    self.delegate = delegate;
    self.vehiclesBoundary = vehiclesBoundary;
    self.vehicles = [NSMutableArray new];
    return self;
}

- (void)getAllNearbyTaxies {
    [self.delegate showLoader];
    [self.vehiclesBoundary fetchTaxiesWithResponse:^(NSArray<Vehicle *> * _Nullable vehicles, NSError * _Nullable error) {
        [self.delegate dismissLoader];
        if (error) {
            [self.delegate showToast:error.localizedDescription];
        }
        else {
            if (vehicles.count) {
                [self handleSuccessResponse:vehicles];
            }
        }
    }];
}

- (void)handleSuccessResponse:(NSArray <Vehicle *>*)vehicles {
    if ([self.vehicles count]) {
        [self.vehicles removeAllObjects];
    }
    [self.vehicles addObjectsFromArray:vehicles];
    [self.delegate updateVehicleContent];
}

-(void)getUserAddress {
    CLLocationCoordinate2D location = [VehicleDirection myLocationCoordinate];
    [ReverseGeocoding geocodeWithLatitude:location.latitude longitude:location.longitude completion:^(NSString * _Nullable address, NSError * _Nullable error) {
        if (!error)
            [self.delegate updateViewTitle:address];
    }];
}

@end
