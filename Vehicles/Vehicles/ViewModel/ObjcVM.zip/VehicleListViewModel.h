//
//  VehicleListViewModel.h
//  FreeNowVehicles
//
//  Created by Ashish Patel on 2021/11/20.
//

#import <Foundation/Foundation.h>
#import "VehicleListDelegate.h"
@protocol VehiclesBoundary;
@class Vehicle;

NS_ASSUME_NONNULL_BEGIN

@interface VehicleListViewModel: NSObject
@property (nonatomic, readonly) NSMutableArray<Vehicle *> *vehicles;

- (instancetype)initWithDelegate:(id <VehicleListDelegate>)delegate withVehiclesBoundary:(id <VehiclesBoundary>)vehiclesBoundry;
- (void)getAllNearbyTaxies;
- (void)getUserAddress;
@end

NS_ASSUME_NONNULL_END
